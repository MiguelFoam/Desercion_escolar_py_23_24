CREATE SCHEMA IF NOT EXISTS proyecto_co2;

DROP TABLE IF EXISTS proyecto_co2.emisiones_co2;

CREATE TABLE proyecto_co2.emisiones_co2(
	id SERIAL PRIMARY KEY,
	pais VARCHAR(100) NOT NULL,
	anho INTEGER NOT NULL,
	poblacion BIGINT,
	pib FLOAT,
	co2 FLOAT,
	co2_per_capita FLOAT
);

SELECT * FROM proyecto_co2.emisiones_co2 ec LIMIT 100;