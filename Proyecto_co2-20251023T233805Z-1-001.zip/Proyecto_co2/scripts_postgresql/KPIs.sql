/*
 * CONSULTAS KPIs
 * */

/*
 * 1.Cantidad de países que lograron reducir sus emisiones entre el 2000 y el 2019
 * Tomamos como referencia este rango ya que debido a la pandemia del 2020 se espera 
 * una reducción considerable en la producción de gases con efecto invernadero en el mundo
 * por los motivos de ceses de algunas fábricas, transporte estancados, etc. Ya que nos interesa más
 * concluir si hay países con políticas prácticas que ayuden a la reducción de los mismos y 
 * cuidado del planeta
 * */
/*
 * Creamos primero un CTE, que es una especie de tabla temporal que se puede usar como una tabla auxiliar
 * para consultas
 * */
WITH comparacion_emisiones_co2 AS (
	SELECT 
		pais,
		MAX(CASE WHEN anho = 2000 THEN co2 ELSE NULL END) AS co2_2000,
		MAX(CASE WHEN anho = 2019 THEN co2 ELSE NULL END) AS co2_2019
		FROM proyecto_co2.emisiones_co2 ec
		GROUP BY pais
)

SELECT COUNT(*) AS paises_con_reduccion FROM comparacion_emisiones_co2
WHERE co2_2019 < co2_2000
AND co2_2019 IS NOT NULL
AND co2_2000 IS NOT NULL;

/*
 *Si queremos saber cúales son esos paises ejecutar la siguiente consulta
 *SELECT pais FROM comparacion_emisiones_co2
 *WHERE co2_2019 < co2_2000
 *AND co2_2019 IS NOT NULL
 *ADN co2_2000 IS NOT NULL;  
 */

/*
 * 2.Países con baja emision per cápita en el año 2020
 * */

SELECT COUNT(*) AS paises_con_baja_emisiones FROM proyecto_co2.emisiones_co2 ec 
WHERE anho = 2020
AND ec.co2_per_capita < 5 /*5 toneladas*/
AND ec.co2_per_capita IS NOT NULL;

