/*
Metricas


1. Total de Emisiones de CO2 de todos los países en 2020 y 2023 
(Hacemos una comparativa de lo que fue el año de pandemia con uno postpandemia) 
*/

 SELECT anho , SUM(co2) AS total_emisiones_co2 FROM proyecto_co2.emisiones_co2 ec
 WHERE anho IN (2020,2023) GROUP BY anho ORDER BY anho;
 
 /*
2. Promedio de emisiones per cápita en el año 2023.
	Compararemos países con una población similar a la de Paraguay
 
 */
 
 SELECT pais, poblacion, co2_per_capita FROM proyecto_co2.emisiones_co2 ec 
 WHERE anho = 2023 AND poblacion BETWEEN 5000000 AND 9000000
 ORDER BY co2_per_capita DESC;
 
 
 /*
  * 3. Sumamos las emisiones totales de cada país para poder hacer un top 5
  * 	de produccion de gases con efecto invernadero por persona.
  * */
 
 SELECT pais, SUM(co2_per_capita) AS total_co2_per_capita FROM proyecto_co2.emisiones_co2 ec
 WHERE anho BETWEEN 2000 AND 2023 AND ec.co2_per_capita IS NOT NULL
 GROUP BY pais ORDER BY total_co2_per_capita DESC
 LIMIT 5;
 